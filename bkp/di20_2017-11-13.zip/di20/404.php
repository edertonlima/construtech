<?php
	header('location: '.get_home_url());
?>