<section class="box-content contato cinza" id="contato">
	<div class="container">

		<div class="row">
			<div class="col-6">
				<h3>Tem uma ideia de negócio ou uma startup no setor e busca um sócio para crescer? É investidor e acredita no potencial de um dos principais setores da economia?</h3>
				<p class="text-contato">
					<span>#MakeConstructionGreatAgain</span>
					Se você se identifica com o nosso propósito, deixe seus contatos e vamos conversar!r.
				</p>
			</div>

			<div class="col-6">

				<form>
					<fieldset>
						<input type="" name="nome" placeholder="Nome:">
					</fieldset>

					<fieldset>
						<input type="" name="email" placeholder="E-mail:">
					</fieldset>

					<fieldset>
						<textarea name="mensagem" placeholder="Como podemos ajudar:"></textarea>
					</fieldset>

					<fieldset>
						<p class="msg-form"></p>
						<button class="enviar">ENVIAR</button>
					</fieldset>
				</form>

			</div>
		</div>

	</div>
</section>